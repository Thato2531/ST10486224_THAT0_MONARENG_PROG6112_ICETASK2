/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.clinicapp;

/**
 *
 * @author Student
 */
public class ClinicApp {

    public static void main(String[] args) {

        ClinicManagementSystem clinic =
                new ClinicManagementSystem();

        // Sample General patient
        Patient generalPatient = new GeneralPatient(
            "P001",
            "Thato",
            "Monareng",
            "15/05/2003",
            "0712345678",
            "thato@gmail.com",
            "No known medical history",
            PatientType.GENERAL,
            "Dr Smith",
            "Discovery"
        );

        // Sample Specialist patient
        Patient specialistPatient = new Patient(
            "P002",
            "John",
            "Mokoena",
            "20/08/1995",
            "0723456789",
            "john@gmail.com",
            "Requires specialist consultation",
            PatientType.SPECIALIST
        );

        // Sample Chronic patient
        Patient chronicPatient = new Patient(
            "P003",
            "Sarah",
            "Dlamini",
            "10/11/1980",
            "0734567890",
            "sarah@gmail.com",
            "Regular check-ups required",
            PatientType.CHRONIC
        );

        // Add sample patients
        clinic.addPatient(generalPatient);
        clinic.addPatient(specialistPatient);
        clinic.addPatient(chronicPatient);

        // Book appointment for General patient
        clinic.scheduleAppointment(
            "Monday 9:00 AM",
            "P001"
        );

        // Start application
        clinic.run();
    }
}