/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.clinicapp;

/**
 *
 * @author Student
 */
public class Appointment {

    private String timeSlot;
    private String patientId;
    private AppointmentStatus status;
    private String doctorName;

    public Appointment(String timeSlot, String patientId,
                       AppointmentStatus status,
                       String doctorName) {

        this.timeSlot = timeSlot;
        this.patientId = patientId;
        this.status = status;
        this.doctorName = doctorName;
    }

    public String getTimeSlot() {
        return timeSlot;
    }

    public String getPatientId() {
        return patientId;
    }

    public AppointmentStatus getStatus() {
        return status;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setTimeSlot(String timeSlot) {
        this.timeSlot = timeSlot;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public void setStatus(AppointmentStatus status) {
        this.status = status;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public void displayDetails() {
        System.out.println("------------------------------");
        System.out.println("Time Slot: " + timeSlot);
        System.out.println("Patient ID: " + patientId);
        System.out.println("Status: " + status);
        System.out.println("Doctor: " + doctorName);
        System.out.println("------------------------------");
    }
}
