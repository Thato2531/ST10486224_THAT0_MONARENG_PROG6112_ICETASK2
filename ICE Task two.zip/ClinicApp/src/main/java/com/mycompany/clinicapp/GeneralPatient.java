/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.clinicapp;

/**
 *
 * @author Student
 */
public class GeneralPatient extends Patient {

    private String preferredDoctor;
    private String insuranceProvider;

    public GeneralPatient(String patientId, String firstName,
                          String lastName, String dateOfBirth,
                          String contactNumber, String email,
                          String medicalHistory,
                          PatientType patientType,
                          String preferredDoctor,
                          String insuranceProvider) {

        super(patientId, firstName, lastName,
              dateOfBirth, contactNumber, email,
              medicalHistory, patientType);

        this.preferredDoctor = preferredDoctor;
        this.insuranceProvider = insuranceProvider;
    }

    public String getPreferredDoctor() {
        return preferredDoctor;
    }

    public String getInsuranceProvider() {
        return insuranceProvider;
    }

    public void setPreferredDoctor(String preferredDoctor) {
        this.preferredDoctor = preferredDoctor;
    }

    public void setInsuranceProvider(String insuranceProvider) {
        this.insuranceProvider = insuranceProvider;
    }

    @Override
    public void displayDetails() {

        super.displayDetails();

        System.out.println("Preferred Doctor: " + preferredDoctor);
        System.out.println("Insurance Provider: " + insuranceProvider);
        System.out.println("------------------------------");
    }
}
