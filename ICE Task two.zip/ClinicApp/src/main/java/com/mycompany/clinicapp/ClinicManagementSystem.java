/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.clinicapp;

/**
 *
 * @author Student
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class ClinicManagementSystem {

    private static final String[] DAYS = {
        "Monday",
        "Tuesday",
        "Wednesday"
    };

    private static final String[] TIMES = {
        "9:00 AM",
        "10:00 AM",
        "11:00 AM",
        "2:00 PM",
        "3:00 PM"
    };

    private List<Patient> patients;
    private List<Appointment> appointments;
    private Map<String, String> patientAppointments;

    private Scanner scanner;

    public ClinicManagementSystem() {

        patients = new ArrayList<>();
        appointments = new ArrayList<>();
        patientAppointments = new HashMap<>();

        scanner = new Scanner(System.in);

        initializeAppointments();
    }

    // ==============================
    // APPOINTMENT INITIALIZATION
    // ==============================

    private void initializeAppointments() {

        for (String day : DAYS) {

            for (String time : TIMES) {

                String slot = day + " " + time;

                Appointment appointment = new Appointment(
                    slot,
                    null,
                    AppointmentStatus.AVAILABLE,
                    "Not Assigned"
                );

                appointments.add(appointment);
            }
        }
    }

    // ==============================
    // PATIENT MANAGEMENT
    // ==============================

    public boolean addPatient(Patient patient) {

        if (searchPatient(patient.getPatientId()) != null) {
            return false;
        }

        patients.add(patient);
        return true;
    }

    public Patient searchPatient(String patientId) {

        for (Patient patient : patients) {

            if (patient.getPatientId().equalsIgnoreCase(patientId)) {
                return patient;
            }
        }

        return null;
    }

    public boolean updatePatient(String patientId,
                                 Patient updatedPatient) {

        Patient patient = searchPatient(patientId);

        if (patient == null) {
            return false;
        }

        patient.setFirstName(updatedPatient.getFirstName());
        patient.setLastName(updatedPatient.getLastName());
        patient.setDateOfBirth(updatedPatient.getDateOfBirth());
        patient.setContactNumber(updatedPatient.getContactNumber());
        patient.setEmail(updatedPatient.getEmail());
        patient.setMedicalHistory(updatedPatient.getMedicalHistory());
        patient.setPatientType(updatedPatient.getPatientType());

        return true;
    }

    public boolean deletePatient(String patientId) {

        Patient patient = searchPatient(patientId);

        if (patient == null) {
            return false;
        }

        if (patientAppointments.containsKey(patientId)) {
            return false;
        }

        patients.remove(patient);

        return true;
    }

    public void displayAllPatients() {

        if (patients.isEmpty()) {
            System.out.println("No patients registered.");
            return;
        }

        for (Patient patient : patients) {
            patient.displayDetails();
        }
    }

    // ==============================
    // APPOINTMENT MANAGEMENT
    // ==============================

    public boolean scheduleAppointment(String timeSlot,
                                       String patientId) {

        Patient patient = searchPatient(patientId);

        if (patient == null) {
            return false;
        }

        if (patient.getPatientType() != PatientType.GENERAL) {
            return false;
        }

        if (patientAppointments.containsKey(patientId)) {
            return false;
        }

        for (Appointment appointment : appointments) {

            if (appointment.getTimeSlot().equalsIgnoreCase(timeSlot)) {

                if (appointment.getStatus()
                        != AppointmentStatus.AVAILABLE) {
                    return false;
                }

                appointment.setStatus(AppointmentStatus.BOOKED);
                appointment.setPatientId(patientId);

                patientAppointments.put(patientId, timeSlot);

                return true;
            }
        }

        return false;
    }

    public boolean cancelAppointment(String timeSlot) {

        for (Appointment appointment : appointments) {

            if (appointment.getTimeSlot().equalsIgnoreCase(timeSlot)) {

                if (appointment.getStatus()
                        != AppointmentStatus.BOOKED) {
                    return false;
                }

                String patientId = appointment.getPatientId();

                appointment.setStatus(
                    AppointmentStatus.AVAILABLE
                );

                appointment.setPatientId(null);

                patientAppointments.remove(patientId);

                return true;
            }
        }

        return false;
    }

    public void displaySchedule() {

        System.out.println();
        System.out.println("========== CLINIC SCHEDULE ==========");

        for (String day : DAYS) {

            System.out.println();
            System.out.println(day);

            for (String time : TIMES) {

                String slot = day + " " + time;

                for (Appointment appointment : appointments) {

                    if (appointment.getTimeSlot().equals(slot)) {

                        if (appointment.getStatus()
                                == AppointmentStatus.AVAILABLE) {

                            System.out.println(
                                time + " - AVAILABLE"
                            );

                        } else if (appointment.getStatus()
                                == AppointmentStatus.BOOKED) {

                            Patient patient = searchPatient(
                                appointment.getPatientId()
                            );

                            if (patient != null) {

                                System.out.println(
                                    time + " - BOOKED - "
                                    + patient.getFirstName()
                                    + " "
                                    + patient.getLastName()
                                );

                            } else {

                                System.out.println(
                                    time + " - BOOKED"
                                );
                            }
                        }
                    }
                }
            }
        }

        System.out.println("=====================================");
    }

    public void displayAvailableSlots() {

        System.out.println();
        System.out.println("======= AVAILABLE APPOINTMENTS =======");

        boolean found = false;

        for (Appointment appointment : appointments) {

            if (appointment.getStatus()
                    == AppointmentStatus.AVAILABLE) {

                System.out.println(
                    appointment.getTimeSlot()
                );

                found = true;
            }
        }

        if (!found) {
            System.out.println("No available appointments.");
        }

        System.out.println("======================================");
    }

    public void displayBookedSlots() {

        System.out.println();
        System.out.println("========= BOOKED APPOINTMENTS =========");

        boolean found = false;

        for (Appointment appointment : appointments) {

            if (appointment.getStatus()
                    == AppointmentStatus.BOOKED) {

                Patient patient = searchPatient(
                    appointment.getPatientId()
                );

                if (patient != null) {

                    System.out.println(
                        appointment.getTimeSlot()
                        + " - "
                        + patient.getFirstName()
                        + " "
                        + patient.getLastName()
                    );

                } else {

                    System.out.println(
                        appointment.getTimeSlot()
                    );
                }

                found = true;
            }
        }

        if (!found) {
            System.out.println("No booked appointments.");
        }

        System.out.println("=======================================");
    }

    // ==============================
    // REPORTS
    // ==============================

    public void displayAllPatientsReport() {

        System.out.println();
        System.out.println("========== ALL PATIENTS ==========");

        displayAllPatients();

        System.out.println("==================================");
    }

    public void displayAvailableSlotsReport() {

        displayAvailableSlots();
    }

    public void displayBookedSlotsReport() {

        displayBookedSlots();
    }

    public void displayTotalPatients() {

        System.out.println(
            "Total Registered Patients: "
            + patients.size()
        );
    }

    public void displayTotalBookedSlots() {

        int count = 0;

        for (Appointment appointment : appointments) {

            if (appointment.getStatus()
                    == AppointmentStatus.BOOKED) {

                count++;
            }
        }

        System.out.println(
            "Total Booked Appointments: " + count
        );
    }

    public void displayOccupancyPercentage() {

        int booked = 0;

        for (Appointment appointment : appointments) {

            if (appointment.getStatus()
                    == AppointmentStatus.BOOKED) {

                booked++;
            }
        }

        double percentage =
            ((double) booked / appointments.size()) * 100;

        System.out.printf(
            "Clinic Occupancy: %.2f%%%n",
            percentage
        );
    }

    // ==============================
    // MAIN MENU
    // ==============================

    public void run() {

        boolean running = true;

        while (running) {

            System.out.println();
            System.out.println("==========================================");
            System.out.println("   CLINIC PATIENT MANAGEMENT SYSTEM");
            System.out.println("==========================================");
            System.out.println("1. Patient Management");
            System.out.println("2. Appointment Management");
            System.out.println("3. View Reports");
            System.out.println("4. Exit");

            System.out.print("Enter your choice: ");

            String choice = scanner.nextLine();

            switch (choice) {

                case "1":
                    patientMenu();
                    break;

                case "2":
                    appointmentMenu();
                    break;

                case "3":
                    reportsMenu();
                    break;

                case "4":
                    running = false;
                    System.out.println("Goodbye!");
                    break;

                default:
                    System.out.println(
                        "Invalid choice. Please try again."
                    );
            }
        }
    }

    // ==============================
    // PATIENT MENU
    // ==============================

    private void patientMenu() {

        boolean back = false;

        while (!back) {

            System.out.println();
            System.out.println("======= PATIENT MANAGEMENT =======");
            System.out.println("1. Register New Patient");
            System.out.println("2. Search for Patient");
            System.out.println("3. Update Patient Details");
            System.out.println("4. Delete Patient");
            System.out.println("5. Display All Patients");
            System.out.println("6. Back to Main Menu");

            System.out.print("Enter your choice: ");

            String choice = scanner.nextLine();

            switch (choice) {

                case "1":
                    registerPatient();
                    break;

                case "2":
                    searchPatientMenu();
                    break;

                case "3":
                    updatePatientMenu();
                    break;

                case "4":
                    deletePatientMenu();
                    break;

                case "5":
                    displayAllPatients();
                    break;

                case "6":
                    back = true;
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    // ==============================
    // REGISTER PATIENT
    // ==============================

    private void registerPatient() {

        System.out.println();
        System.out.println("======= REGISTER PATIENT =======");

        String patientId;

        while (true) {

            System.out.print("Patient ID (P001-P999): ");
            patientId = scanner.nextLine();

            if (!isValidPatientId(patientId)) {

                System.out.println(
                    "Invalid Patient ID."
                );

            } else if (searchPatient(patientId) != null) {

                System.out.println(
                    "Patient ID already exists."
                );

            } else {

                break;
            }
        }

        System.out.print("First Name: ");
        String firstName = scanner.nextLine();

        System.out.print("Last Name: ");
        String lastName = scanner.nextLine();

        String dateOfBirth;

        while (true) {

            System.out.print("Date of Birth (DD/MM/YYYY): ");
            dateOfBirth = scanner.nextLine();

            if (isValidDate(dateOfBirth)) {
                break;
            }

            System.out.println("Invalid date format.");
        }

        String contactNumber;

        while (true) {

            System.out.print("Contact Number (10 digits): ");
            contactNumber = scanner.nextLine();

            if (isValidContact(contactNumber)) {
                break;
            }

            System.out.println(
                "Contact number must contain 10 digits."
            );
        }

        String email;

        while (true) {

            System.out.print("Email: ");
            email = scanner.nextLine();

            if (isValidEmail(email)) {
                break;
            }

            System.out.println("Invalid email.");
        }

        System.out.print("Medical History: ");
        String medicalHistory = scanner.nextLine();

        PatientType type = choosePatientType();

        Patient patient;

        if (type == PatientType.GENERAL) {

            System.out.print("Preferred Doctor: ");
            String doctor = scanner.nextLine();

            System.out.print("Insurance Provider: ");
            String insurance = scanner.nextLine();

            patient = new GeneralPatient(
                patientId,
                firstName,
                lastName,
                dateOfBirth,
                contactNumber,
                email,
                medicalHistory,
                type,
                doctor,
                insurance
            );

        } else {

            patient = new Patient(
                patientId,
                firstName,
                lastName,
                dateOfBirth,
                contactNumber,
                email,
                medicalHistory,
                type
            );
        }

        if (addPatient(patient)) {

            System.out.println(
                "Patient registered successfully!"
            );

        } else {

            System.out.println(
                "Patient registration failed."
            );
        }
    }

    private PatientType choosePatientType() {

        while (true) {

            System.out.println("1. General");
            System.out.println("2. Specialist");
            System.out.println("3. Chronic");

            System.out.print("Choose patient type: ");

            String choice = scanner.nextLine();

            switch (choice) {

                case "1":
                    return PatientType.GENERAL;

                case "2":
                    return PatientType.SPECIALIST;

                case "3":
                    return PatientType.CHRONIC;

                default:
                    System.out.println(
                        "Invalid choice."
                    );
            }
        }
    }

    // ==============================
    // SEARCH
    // ==============================

    private void searchPatientMenu() {

        System.out.print("Enter Patient ID: ");

        String id = scanner.nextLine();

        Patient patient = searchPatient(id);

        if (patient == null) {

            System.out.println("Patient not found.");

        } else {

            patient.displayDetails();
        }
    }

    // ==============================
    // UPDATE
    // ==============================

    private void updatePatientMenu() {

        System.out.print("Enter Patient ID: ");

        String id = scanner.nextLine();

        Patient patient = searchPatient(id);

        if (patient == null) {

            System.out.println("Patient not found.");
            return;
        }

        System.out.print("New First Name: ");
        String firstName = scanner.nextLine();

        System.out.print("New Last Name: ");
        String lastName = scanner.nextLine();

        System.out.print("New Date of Birth: ");
        String dob = scanner.nextLine();

        System.out.print("New Contact Number: ");
        String contact = scanner.nextLine();

        System.out.print("New Email: ");
        String email = scanner.nextLine();

        System.out.print("New Medical History: ");
        String history = scanner.nextLine();

        PatientType type = choosePatientType();

        Patient updated = new Patient(
            id,
            firstName,
            lastName,
            dob,
            contact,
            email,
            history,
            type
        );

        if (updatePatient(id, updated)) {

            System.out.println(
                "Patient updated successfully."
            );

        } else {

            System.out.println(
                "Patient update failed."
            );
        }
    }

    // ==============================
    // DELETE
    // ==============================

    private void deletePatientMenu() {

        System.out.print("Enter Patient ID: ");

        String id = scanner.nextLine();

        if (deletePatient(id)) {

            System.out.println(
                "Patient deleted successfully."
            );

        } else {

            System.out.println(
                "Patient could not be deleted."
            );
        }
    }

    // ==============================
    // APPOINTMENT MENU
    // ==============================

    private void appointmentMenu() {

        boolean back = false;

        while (!back) {

            System.out.println();
            System.out.println("===== APPOINTMENT MANAGEMENT =====");
            System.out.println("1. Schedule Appointment");
            System.out.println("2. Cancel Appointment");
            System.out.println("3. View Clinic Schedule");
            System.out.println("4. View Available Appointments");
            System.out.println("5. View Booked Appointments");
            System.out.println("6. Back to Main Menu");

            System.out.print("Enter your choice: ");

            String choice = scanner.nextLine();

            switch (choice) {

                case "1":
                    scheduleAppointmentMenu();
                    break;

                case "2":
                    cancelAppointmentMenu();
                    break;

                case "3":
                    displaySchedule();
                    break;

                case "4":
                    displayAvailableSlots();
                    break;

                case "5":
                    displayBookedSlots();
                    break;

                case "6":
                    back = true;
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private void scheduleAppointmentMenu() {

        displayAvailableSlots();

        System.out.print("Enter Patient ID: ");
        String id = scanner.nextLine();

        System.out.print(
            "Enter time slot exactly as shown above: "
        );

        String slot = scanner.nextLine();

        if (scheduleAppointment(slot, id)) {

            System.out.println(
                "Appointment booked successfully!"
            );

        } else {

            System.out.println(
                "Appointment could not be booked."
            );
        }
    }

    private void cancelAppointmentMenu() {

        displayBookedSlots();

        System.out.print("Enter time slot to cancel: ");

        String slot = scanner.nextLine();

        if (cancelAppointment(slot)) {

            System.out.println(
                "Appointment cancelled successfully!"
            );

        } else {

            System.out.println(
                "Appointment could not be cancelled."
            );
        }
    }

    // ==============================
    // REPORT MENU
    // ==============================

    private void reportsMenu() {

        boolean back = false;

        while (!back) {

            System.out.println();
            System.out.println("========== REPORTS ==========");
            System.out.println("1. All Registered Patients");
            System.out.println("2. All Available Appointments");
            System.out.println("3. All Booked Appointments");
            System.out.println("4. Total Registered Patients");
            System.out.println("5. Total Booked Appointments");
            System.out.println("6. Clinic Occupancy Percentage");
            System.out.println("7. Back to Main Menu");

            System.out.print("Enter your choice: ");

            String choice = scanner.nextLine();

            switch (choice) {

                case "1":
                    displayAllPatientsReport();
                    break;

                case "2":
                    displayAvailableSlotsReport();
                    break;

                case "3":
                    displayBookedSlotsReport();
                    break;

                case "4":
                    displayTotalPatients();
                    break;

                case "5":
                    displayTotalBookedSlots();
                    break;

                case "6":
                    displayOccupancyPercentage();
                    break;

                case "7":
                    back = true;
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    // ==============================
    // VALIDATION
    // ==============================

    private boolean isValidPatientId(String id) {

        return id.matches("P[0-9]{3}");
    }

    private boolean isValidEmail(String email) {

        return email.contains("@")
                && email.contains(".");
    }

    private boolean isValidContact(String number) {

        return number.matches("[0-9]{10}");
    }

    private boolean isValidDate(String date) {

        return date.matches(
            "(0[1-9]|[12][0-9]|3[01])/"
            + "(0[1-9]|1[0-2])/"
            + "[0-9]{4}"
        );
    }
}
