/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.clinicapp;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ClinicManagementSystemTest {

    private ClinicManagementSystem clinic;

    @BeforeEach
    public void setUp() {
        clinic = new ClinicManagementSystem();
    }

    // TEST 1: Register a patient
    @Test
    public void testRegisterPatient() {

        Patient patient = new Patient(
                "P001",
                "Thato",
                "Monareng",
                "15/05/2003",
                "0712345678",
                "thato@gmail.com",
                "No known medical history",
                PatientType.GENERAL
        );

        boolean result = clinic.addPatient(patient);

        assertTrue(result);
    }

    // TEST 2: Search for a patient
    @Test
    public void testSearchPatient() {

        Patient patient = new Patient(
                "P001",
                "Thato",
                "Monareng",
                "15/05/2003",
                "0712345678",
                "thato@gmail.com",
                "No known medical history",
                PatientType.GENERAL
        );

        clinic.addPatient(patient);

        Patient foundPatient = clinic.searchPatient("P001");

        assertNotNull(foundPatient);
        assertEquals("P001", foundPatient.getPatientId());
    }

    // TEST 3: Update patient details
    @Test
    public void testUpdatePatient() {

        Patient patient = new Patient(
                "P001",
                "Thato",
                "Monareng",
                "15/05/2003",
                "0712345678",
                "thato@gmail.com",
                "No known medical history",
                PatientType.GENERAL
        );

        clinic.addPatient(patient);

        Patient updatedPatient = new Patient(
                "P001",
                "Thato",
                "Mokoena",
                "15/05/2003",
                "0799999999",
                "thato@gmail.com",
                "Updated medical history",
                PatientType.GENERAL
        );

        boolean result = clinic.updatePatient(
                "P001",
                updatedPatient
        );

        assertTrue(result);

        Patient patientAfterUpdate =
                clinic.searchPatient("P001");

        assertEquals(
                "Mokoena",
                patientAfterUpdate.getLastName()
        );
    }

    // TEST 4: Delete a patient
    @Test
    public void testDeletePatient() {

        Patient patient = new Patient(
                "P001",
                "Thato",
                "Monareng",
                "15/05/2003",
                "0712345678",
                "thato@gmail.com",
                "No known medical history",
                PatientType.GENERAL
        );

        clinic.addPatient(patient);

        boolean result = clinic.deletePatient("P001");

        assertTrue(result);

        Patient deletedPatient =
                clinic.searchPatient("P001");

        assertNull(deletedPatient);
    }

    // TEST 5: Schedule an appointment
    @Test
    public void testScheduleAppointment() {

        Patient patient = new Patient(
                "P001",
                "Thato",
                "Monareng",
                "15/05/2003",
                "0712345678",
                "thato@gmail.com",
                "No known medical history",
                PatientType.GENERAL
        );

        clinic.addPatient(patient);

        boolean result = clinic.scheduleAppointment(
                "Monday 9:00 AM",
                "P001"
        );

        assertTrue(result);
    }

    // TEST 6: Cancel an appointment
    @Test
    public void testCancelAppointment() {

        Patient patient = new Patient(
                "P001",
                "Thato",
                "Monareng",
                "15/05/2003",
                "0712345678",
                "thato@gmail.com",
                "No known medical history",
                PatientType.GENERAL
        );

        clinic.addPatient(patient);

        clinic.scheduleAppointment(
                "Monday 9:00 AM",
                "P001"
        );

        boolean result = clinic.cancelAppointment(
                "Monday 9:00 AM"
        );

        assertTrue(result);
    }

    // TEST 7: Prevent duplicate Patient IDs
    @Test
    public void testPreventDuplicatePatientId() {

        Patient patient1 = new Patient(
                "P001",
                "Thato",
                "Monareng",
                "15/05/2003",
                "0712345678",
                "thato@gmail.com",
                "No known medical history",
                PatientType.GENERAL
        );

        Patient patient2 = new Patient(
                "P001",
                "John",
                "Mokoena",
                "20/08/1995",
                "0723456789",
                "john@gmail.com",
                "Asthma",
                PatientType.GENERAL
        );

        boolean firstResult = clinic.addPatient(patient1);

        boolean secondResult = clinic.addPatient(patient2);

        assertTrue(firstResult);
        assertFalse(secondResult);
    }

    // TEST 8: Prevent booking an already booked appointment
    @Test
    public void testPreventDoubleBooking() {

        Patient patient1 = new Patient(
                "P001",
                "Thato",
                "Monareng",
                "15/05/2003",
                "0712345678",
                "thato@gmail.com",
                "No known medical history",
                PatientType.GENERAL
        );

        Patient patient2 = new Patient(
                "P002",
                "John",
                "Mokoena",
                "20/08/1995",
                "0723456789",
                "john@gmail.com",
                "Asthma",
                PatientType.GENERAL
        );

        clinic.addPatient(patient1);
        clinic.addPatient(patient2);

        boolean firstBooking =
                clinic.scheduleAppointment(
                        "Monday 9:00 AM",
                        "P001"
                );

        boolean secondBooking =
                clinic.scheduleAppointment(
                        "Monday 9:00 AM",
                        "P002"
                );

        assertTrue(firstBooking);
        assertFalse(secondBooking);
    }

    // TEST 9: Prevent scheduling when all slots are occupied
    @Test
    public void testAllSlotsOccupied() {

        String[] slots = {
                "Monday 9:00 AM",
                "Monday 10:00 AM",
                "Monday 11:00 AM",
                "Monday 2:00 PM",
                "Monday 3:00 PM",
                "Tuesday 9:00 AM",
                "Tuesday 10:00 AM",
                "Tuesday 11:00 AM",
                "Tuesday 2:00 PM",
                "Tuesday 3:00 PM",
                "Wednesday 9:00 AM",
                "Wednesday 10:00 AM",
                "Wednesday 11:00 AM",
                "Wednesday 2:00 PM",
                "Wednesday 3:00 PM"
        };

        for (int i = 0; i < 15; i++) {

            String patientId =
                    String.format("P%03d", i + 1);

            Patient patient = new Patient(
                    patientId,
                    "Patient" + i,
                    "Test",
                    "15/05/2003",
                    "0712345678",
                    "test" + i + "@gmail.com",
                    "No history",
                    PatientType.GENERAL
            );

            clinic.addPatient(patient);

            boolean booked =
                    clinic.scheduleAppointment(
                            slots[i],
                            patientId
                    );

            assertTrue(booked);
        }

        Patient extraPatient = new Patient(
                "P016",
                "Extra",
                "Patient",
                "15/05/2003",
                "0712345678",
                "extra@gmail.com",
                "No history",
                PatientType.GENERAL
        );

        clinic.addPatient(extraPatient);

        boolean result =
                clinic.scheduleAppointment(
                        "Monday 9:00 AM",
                        "P016"
                );

        assertFalse(result);
    }
}
